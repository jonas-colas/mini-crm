

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="py-3 text-center">
    <h2>Empresas Registradas</h2>
  </div>
  <div class="float-right my-3">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addEmpresa">
      <i class="fa fa-plus-circle"> &nbsp;Agregar Empresa</i> 
    </button>
  </div><br>
  <?php if(session()->has('message')): ?>
    <div class="mt-5">
      <p class="alert alert-success"><i class="fa fa-check-circle"></i>&nbsp;<?php echo e(Session::get('message')); ?></p>
    </div>
  <?php endif; ?> 
  <?php if(session()->has('error')): ?>
    <div class="mt-5">
      <p class="alert alert-danger"><i class="fa fa-times-circle"></i>&nbsp;<?php echo e(Session::get('error')); ?></p>
    </div>
  <?php endif; ?>
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Email</th>
        <th>Logotipo</th>
        <th>Sitio Web </th>
        <th>opciones</th> 
      </tr>
    </thead>
    <tbody>
      <?php if($empresas): ?>
        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($emp->nombre); ?></td>
            <td><?php echo e($emp->email); ?></td>
            <td><img src="<?php echo e(asset('storage/'.$emp->logotipo)); ?>" width="100" /> </td>
            <td><?php echo e($emp->website); ?></td>
            <td>
              <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update-<?php echo e($emp->id); ?>">
                <i class="fa fa-edit"></i>
              </button>
              <div class="modal fade" id="update-<?php echo e($emp->id); ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header bg-warning">
                      <h5 class="modal-title" id="exampleModalLabel">Actualizar Empresa</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo e(url('empresas/edit')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(method_field('PUT')); ?>

                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label class=""> <b>Nombre de la Empresa </b><small class="text-danger">(*)</small></label>
                          <input type="text" class="form-control" name="nombre" value="<?php echo e($emp->nombre); ?>">
                          <input type="hidden" name="id" value="<?php echo e($emp->id); ?>">
                        </div>
                        <div class="form-group">
                          <label class=""> <b>Email de la empresa</b></label>
                          <input type="text" class="form-control" name="email" value="<?php echo e($emp->email); ?>">
                        </div>
                        <div class="form-group">
                          <label class=""> <b>Sitio Web (*)</b></label>
                          <input type="text" class="form-control" name="website" value="<?php echo e($emp->website); ?>">
                        </div>
                        <div class="form-group">
                          <label class=""> <b>Logotipo</b></label>
                          <span><img src="<?php echo e(asset('storage/'.$emp->logotipo)); ?>" width="100" /></span>
                          <input type="file" class="form-control" name="logotipo" >
                        </div>
                        <div class="float-right">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                          <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>

              <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#destroy-<?php echo e($emp->id); ?>">
                <i class="fa fa-trash"></i>
              </button>
              <div class="modal fade" id="destroy-<?php echo e($emp->id); ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                  <div class="modal-content modal-sm">
                    <div class="modal-header bg-warning">
                      <h5 class="modal-title" id="exampleModalLabel">Eliminar Registro</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo e(url('empresas/destroy')); ?>" method="post" accept-charset="utf-8">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo csrf_field(); ?>
                        <p>Eliminar Registro</p>
                        <input type="hidden" name="id" value="<?php echo e($emp->id); ?>">
                        <div class="float-right">
                          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                          <button type="submit" class="btn btn-primary">Eliminar</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>

            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
        <p class="alert alert-danger">No Hay Empresa Registrada !</p>
      <?php endif; ?>
    </tbody>
  </table>
  <div class="pagination-bar text-center">
    <nav aria-label="Page navigation " class="d-inline-b">
      <?php if(($empresas) != null): ?>
        <?php echo e($empresas->links()); ?>

      <?php endif; ?>
    </nav>
  </div>

</div>


<!-- Modal Agregar-->
<div class="modal fade" id="addEmpresa" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white" id="exampleModalLabel">Agregar Nueva Empresa</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(url('empresas/store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label class=""> <b>Nombre de la Empresa </b><small class="text-danger">(*)</small></label>
              <input type="text" class="form-control" name="nombre" placeholder="ingrese nombre">
            </div>
            <div class="form-group">
              <label class=""> <b>Email de la Empresa</b></label>
              <input type="text" class="form-control" name="email" placeholder="ingrese email">
            </div>
            <div class="form-group">
              <label class=""> <b>Sitio Web  (Si posee)</b></label>
              <input type="text" class="form-control" name="website" placeholder="ingrese website">
            </div>
            <div class="form-group">
              <label class=""> <b>Logotipo</b></label>
              <input type="file" class="form-control" name="logotipo" >
            </div>
            <div class="float-right">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!--fin Modal Agregar-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mini-crm\resources\views/admin/empresas.blade.php ENDPATH**/ ?>