## Pasos a seguir y comandos para hacer funcionar la app

-composer install
-create .env file
-create db named "crm"
-php artisan ui vue --auth 
-php artisan migrate
-php artisan db:seed



